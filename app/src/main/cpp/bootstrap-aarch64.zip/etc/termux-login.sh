##
## This script is sourced by /data/data/com.nocode/files/usr/bin/login before executing shell.
##
