if [ ! -f /data/data/com.nocode/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.nocode/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.nocode/files/home/.termux
	cp /data/data/com.nocode/files/usr/share/examples/termux/termux.properties /data/data/com.nocode/files/home/.termux/
fi
